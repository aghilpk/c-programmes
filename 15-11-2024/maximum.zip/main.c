/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/#include <stdio.h>
// Write a function that takes two integers as parameters and returns the maximum of the two.

#include<stdio.h>
int maximum(int a,int b){
if(a>b)
 return a;
else{
 return b;
 }
}
int main()
{
    int n1,n2;
    printf("enter two numbers:");
    scanf("%d%d",&n1,&n2);
    printf("maximum %dis%d:%d",n1,n2,maximum(n1,n2));

    return 0;
}
