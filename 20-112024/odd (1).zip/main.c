/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int sumOfOddDigits(int number) {
    int sum = 0;
    int digit;

    while (number > 0) {
        digit = number % 10; 
        if (digit % 2 != 0) { 
            sum += digit;
        }
        number /= 10; 
    }

    return sum;
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    int result = sumOfOddDigits(num);
    printf("The sum of odd digits is: %d\n", result);

    return 0;
}
